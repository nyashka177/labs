l=str(input())
s=str(input())
k=0
for i in range(0, len(l)):
    if l[i]==s:
        k=k+1
        if k==2: res=i
print(res)