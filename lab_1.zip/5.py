str = str(input())
for i in range(len(str)):
    print(str[len(str)-i-1],end="")