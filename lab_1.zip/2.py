a = [1,2,3,4,5]
n = int(input())
if not (-1<n<len(a)):
    print(-1)
else:
    a[n]=a[n]**n
    print(a)