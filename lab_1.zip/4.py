number = str(input())
n=0
for i in range(len(number)):
    if number[i]==str(0):
        n=n+1
    else:
        n=0
print(n)