s=[4,15,20,20,15,18,5,20,15,19,8,1]
d = {}
for e in s:
    if e in d:
        d[e]=d[e]+1
    else:
        d[e]=1
i=0
while i<len(s):
    if s[i] in d and d[s[i]]==1:
        s.remove(s[i])
        i=i-1
    i=i+1
print(s)