a=[1,[2,3],[4,[5,6]]]
print(raspakovka(a))
def raspakovka(a):
    res=[]
    for e in a:
        