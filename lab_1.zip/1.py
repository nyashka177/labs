a = [1,2,3,4,5]
def Huh(a, i):
    print (a[i])
Huh(a, 0)
Huh(a, 2)
Huh(a, len(a)-1)