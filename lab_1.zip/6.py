a=str(input()).split()
k=0
for e in a:
    if e==a[0]:
        k=1
    else:
        k=0
if k==1: print('yes')
else: print ('no')