d = {'first': 1, 'second': 2}
max=0
for k, v in d.items():
    if v>max:
        max=v
        key=k
print(key)