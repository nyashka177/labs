cringe=str(input())
while len(cringe)<16: cringe=input()

a,b,c,d=False,False,False,True
for e in cringe:
    if e.isupper(): a=True
    elif e.islower(): b=True
    elif e.isnumeric(): c=True
    else: d=False
if a and b and c and d:
    print('cool')